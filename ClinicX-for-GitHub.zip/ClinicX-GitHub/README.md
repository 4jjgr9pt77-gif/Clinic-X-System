# Clinic X

Clinic Management System (based on CliniSYS GP concepts).

## Run locally

```bash
node server.js
```

Open http://localhost:3000

## Login

- admin / admin123
- doctor / doctor123
- nurse / nurse123
- cashier / cashier123

## Deploy on Render

- Runtime: Node
- Build Command: (empty)
- Start Command: `node server.js`
